
#ifndef _CONFIG_H
#define _CONFIG_H

#include <stdio.h>


//#define DBG_PRINTF(...)  
#define DBG_PRINTF printf

#define FB_DEVICE_NAME "/dev/fb0"

#endif /* _CONFIG_H */
