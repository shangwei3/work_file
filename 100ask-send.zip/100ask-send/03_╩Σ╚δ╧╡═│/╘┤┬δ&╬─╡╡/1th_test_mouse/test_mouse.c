#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/input.h>

int main(void)
{
    //1、定义一个结构体变量用来描述input事件
    struct input_event event_mouse ;
    //2、打开input设备的事件节点  我的通用USB鼠标事件的节点是event2
    int fd    = -1 ;
	fd = open("/dev/input/event2", O_RDONLY);
    if(-1 == fd)
    {
        printf("open mouse event fair!\n");
        return -1 ;
    }

    while(1)
    {
        //3、读事件
        read(fd, &event_mouse, sizeof(event_mouse));
		if(EV_ABS == event_mouse.type || EV_REL == event_mouse.type)
		{
            //code表示相对位移X或者Y，当判断是X时，打印X的相对位移value
			//当判断是Y时，打印Y的相对位移value
            if(event_mouse.code == REL_X)
            {
				printf("event_mouse.code_X:%d\n", event_mouse.code);
                printf("event_mouse.value_X:%d\n", event_mouse.value);
            }
            else if(event_mouse.code == REL_Y)
            {
                printf("event_mouse.code_Y:%d\n", event_mouse.code);
                printf("event_mouse.value_Y:%d\n", event_mouse.value);
            }
		
		}
    }
    close(fd);
    return 0 ;
}
