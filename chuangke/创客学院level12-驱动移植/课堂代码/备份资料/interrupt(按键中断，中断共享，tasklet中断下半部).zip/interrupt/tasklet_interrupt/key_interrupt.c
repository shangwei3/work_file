#include <linux/module.h>
#include <linux/init.h>
#include <linux/of.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>

 MODULE_LICENSE("GPL");

 struct key_device{
 	int irq;
	struct tasklet_struct  tasklet;
 };


//�°벿����
 static void key_tasklet_handler(unsigned long data)
 {
 	struct key_device *pkey = (struct key_device *)data;
	
	printk("key tasklet handler : %d\n",pkey->irq);

	return;
 }

//�ϰ벿����
 irqreturn_t fs4412_key_handler(int irq, void *dev_id)
 {
 	struct key_device *pkey = (struct key_device *)dev_id;
	
	printk("key press , irq:%d ,dev_id:%p\n",irq,dev_id);

	tasklet_schedule(&pkey->tasklet);
	
	return IRQ_HANDLED;
 }

 

static int fs4412_keys_probe(struct platform_device *pdev)
{
	int ret;
	struct resource *res;
	struct key_device *pkey;
	
	printk("fs4412 keys probe!\n");

	res = platform_get_resource(pdev,IORESOURCE_IRQ,0);
	if(!res){
		printk("Fail to platform get irq resource\n");
		return -ENODEV;
	}
	
	printk("resource flags   :%#x\n",res->flags);//flags��4bit�����豸����ָ���Ĵ�����ʽ
	printk("interrupt number : %d\n",res->start);
	printk("interrupt name   : %s\n",res->name);

	pkey = devm_kmalloc(&pdev->dev,sizeof(*pkey),GFP_KERNEL);
	if(!pkey){
		printk("Fail to kmalloc\n");
		return -ENOMEM;
	}

	pkey->irq = res->start;

	tasklet_init(&pkey->tasklet,key_tasklet_handler, (unsigned long)pkey);

	ret = devm_request_irq(&pdev->dev,res->start,fs4412_key_handler,
			res->flags & IRQF_TRIGGER_MASK,res->name,pkey);
	if (ret) {
		printk("failed to request IRQ%u: %d\n", res->start, ret);
		return ret;
	}
	
	
	return 0;
}

static int fs4412_keys_remove(struct platform_device *pdev)
{
	//int irq = platform_get_irq(pdev,0);
	//free_irq(irq,NULL);
	
	return 0;
}


static const struct of_device_id fs4412_of_match[] = {
	{ .compatible = "fs4412-key", },
	{ }
};


static struct platform_driver fs4412_keys_driver = {
	.driver	= {
		.name	= "fs4412-keys",
		.owner	= THIS_MODULE,
		.of_match_table = fs4412_of_match,
	},
	.probe		= fs4412_keys_probe,
	.remove		= fs4412_keys_remove,
};

#if 0
int key_interrupt_init(void)
{
	return platform_driver_register(&fs4412_keys_driver);
}

void key_interrupt_exit(void)
{
	platform_driver_unregister(&fs4412_keys_driver);
}

module_init(key_interrupt_init);
module_exit(key_interrupt_exit);
#endif 

module_platform_driver(fs4412_keys_driver);