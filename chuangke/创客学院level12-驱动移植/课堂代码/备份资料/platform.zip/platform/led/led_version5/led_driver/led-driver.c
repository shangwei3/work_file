#include <linux/module.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <asm/io.h>
#include "led.h"

MODULE_LICENSE("GPL v2");

enum{
	CON = 0,
	DAT = 4,
};


struct led_des{
	int pin;
	int mode;
	int level;
};

struct led_device{
	dev_t  devno;
	char   state[15];
	struct cdev cdev; //inode->i_cdev
	struct led_des *des;
	struct device *dev;
	void		__iomem *regs;
};

struct class *led_class;


/*
	bug:
		���۲�����һ���豸�ļ������ն��ǲ��������һ��LED��

	ԭ��:
		pled���ָ����ȫ�ֱ�����������ֵ���һ��ƥ���ֵ(���һ��LEDƥ��)

	������ⷽ����
	�����ҵ�ÿ��LED�ƶ�Ӧ��struct led_device�ṹ��

	platform_set_drvdata / platform_get_drvdata
	container_of : ���ݽṹ���Ա��ַ������ṹ���׵�ַ
	struct file��private_data��Ա����ṹ���׵�ַ
 */


void led_on(struct led_device *pled)
{
	int reg_value;
	int pin = pled->des->pin;
	int level = pled->des->level;

	reg_value = readl(pled->regs + DAT);
	reg_value &= ~(1 << pin);
	reg_value |= (level << pin);
	writel(reg_value, pled->regs + DAT);

	return;
}

void led_off(struct led_device *pled)
{
	int reg_value;
	int pin = pled->des->pin;
	int level = pled->des->level;

	reg_value = readl(pled->regs + DAT);
	reg_value &= ~(1 << pin);
	//~0 -> 1111111111111111111111111111111111
	//!0 -> 1 
	reg_value |= (!level << pin);
	writel(reg_value, pled->regs + DAT);

	return;
}


static int led_open(struct inode *inode, struct file *file)
{
	int reg_value;
	int pin,mode;
	struct led_device *pled = container_of(inode->i_cdev,struct led_device,cdev);
	
	printk("led open success!\n");

	file->private_data = pled;

	pin = pled->des->pin;
	mode = pled->des->mode;
	
	reg_value = readl(pled->regs + CON);
	reg_value &= ~(0xf << (4 * pin));
	reg_value |=  (mode << (4 * pin));
	writel(reg_value, pled->regs + CON);
	
	return 0;
}

static int led_release(struct inode *inode, struct file *file)
{
	struct led_device *pled = container_of(inode->i_cdev,struct led_device,cdev);
	
	printk("led release!\n");
	led_off(pled);
	
	return 0;
}


static long led_ioctl(struct file *file,
					unsigned int cmd, unsigned long arg)
{
	struct led_device *pled = file->private_data;
	
	switch(cmd){
		case LEDIOC_ON:
			led_on(pled);
			break;

		case LEDIOC_OFF:
			led_off(pled);
			break;

		default:
			printk("unknown cmd\n");
			return -EINVAL;
	}

	return 0;
}


static const struct file_operations led_fops = {
	.owner		= THIS_MODULE,
	.open		= led_open,
	.unlocked_ioctl	= led_ioctl,
	.release	= led_release,
};


int register_led_chrdev(struct platform_device *pdev)
{
	int ret;
	struct led_device *pled = platform_get_drvdata(pdev);
	
	//pled->cdev.ops = &led_fops;
	cdev_init(&pled->cdev,&led_fops);

	
	//���ʧ�ܣ���̬��ȡ
	//cat /proc/devices
	ret = alloc_chrdev_region(&pled->devno,0,1,dev_name(&pdev->dev));
	if(ret){
		printk("led:couldn't alloc device number\n");
		goto err_register_chrdev_region;
	}
	

	//����cdev��ϵͳ
	ret = cdev_add(&pled->cdev,pled->devno, 1);
	if (ret){
		printk("led:cdev add failure\n");
		goto err_cdev_add;
	}

	//�����豸����Ϣ
	//2.����һ���豸 device name
	pled->dev = device_create(led_class,NULL,pled->devno, NULL,"%s",dev_name(&pdev->dev));
	if (IS_ERR(pled->dev)) {
		printk("Fail to device create\n");
		ret = PTR_ERR(pled->dev);
		goto err_device_create;
	}


	return 0;
	
err_device_create:
	cdev_del(&pled->cdev);
	
err_cdev_add:
	unregister_chrdev_region(pled->devno,1);
	
err_register_chrdev_region:
	return ret;	
	
}

//���豸������ƥ��ɹ�֮�󣬲���ϵͳ���Զ�����probe����
//���Ұ������豸��Ϣ�Ľṹ��struct platform_device���ݹ���
//���������ǾͿ���ͨ��platform_device�ṹ���õ��豸��������Ϣ
static int led_probe(struct platform_device *pdev)
{
	int ret;
	struct resource *res;
	struct led_device *pled;
	struct led_des *platdata;
	

	printk("match: led probe!\n");
	printk("struct platform device name : %s\n",pdev->name);
	printk("struct device name : %s\n",dev_name(&pdev->dev));
	printk("match: driver data : %ld\n",pdev->id_entry->driver_data);

	printk("\n----------------------------------\n");


	//1.��ȡ��Դ:�Ĵ�����Դ,ƽ̨˽�е���Դ
	res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	if (!res){
		printk("Fail to platform get resource\n");
		return -ENODEV;
	}
	printk("reg phy addr : %#x\n",res->start);

	//platdata = pdev->dev.platform_data;
	platdata = dev_get_platdata(&pdev->dev);
	if(!platdata){
		printk("No device private info!\n");
		return -ENODEV;
	}

	printk("pin:%d , mode:%d , level : %d\n",platdata->pin,platdata->mode,platdata->level);

	
	pled = kmalloc(sizeof(*pled),GFP_KERNEL);
	if (!pled) {
		printk("Fail to kmalloc\n");
		return -ENOMEM;
	}

	printk("pled : %p\n",pled);

	platform_set_drvdata(pdev,pled);

	pled->des = platdata;

	//ӳ��������ַ
	pled->regs = ioremap(res->start,resource_size(res));
	if (!pled->regs) {
		printk("Unable to map I/O register");
		ret = -ENOMEM;
		goto err_ioremap;
	}
	
	
	//2.ע���ַ��豸
	ret = register_led_chrdev(pdev);
	if(ret < 0){
		printk("Fail to register led chrdev\n");
		goto err_register_led_chrdev;
	}
	
	return 0;

err_register_led_chrdev:
	iounmap(pled->regs);

err_ioremap:
	kfree(pled);
	return ret;
}

static int led_remove(struct platform_device *pdev)
{
	struct led_device *pled = platform_get_drvdata(pdev);
	
	printk("detach:led remove!\n");
	
	iounmap(pled->regs);
	device_destroy(led_class,pled->devno);
	cdev_del(&pled->cdev);
	unregister_chrdev_region(pled->devno,1);//�ͷ��豸��
	kfree(pled);
	
	return 0;
}

static struct platform_device_id led_driver_ids[] = {
	{
		.name	= "fs4412-led",
		.driver_data	= 1,
	}, {
		.name	= "samsung-led",
		.driver_data	= 0,
	},
	{ },
};

static struct platform_driver led_driver = {
	.probe          = led_probe,
	.remove         = led_remove,
	.id_table       = led_driver_ids,
	.driver         = {
		.name   = "led",
		.owner  = THIS_MODULE,
	},
};


int led_driver_init(void)
{
	//1.����һ���� /sys/class/fs4412-led
	led_class = class_create(THIS_MODULE, "fs4412-led");
	if (IS_ERR(led_class)){//�ж����Ƿ����
		printk("Fail to class create\n");
		return PTR_ERR(led_class);//��ȡ������
	}
	
	return platform_driver_register(&led_driver);
}

void led_driver_exit(void)
{
	platform_driver_unregister(&led_driver);
	class_destroy(led_class);
}

module_init(led_driver_init);
module_exit(led_driver_exit);
