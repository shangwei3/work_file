/*************************************************************************
	> File Name: uart.h
	> Author: 
	> Mail: 
	> Created Time: 2018年01月23日 09时44分27秒 HKT
 ************************************************************************/

#ifndef _UART_H
#define _UART_H

void uart_init(void);
void putc(char c);
void puts(const char *p);

#endif
