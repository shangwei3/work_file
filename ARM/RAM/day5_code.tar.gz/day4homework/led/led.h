#ifndef __LED_H__
#define __LED_H__

void led_init(void);
void led(unsigned char con,unsigned char ctr);
unsigned char get_led_flag(void);


#endif

