#include "exynos_4412.h"
#include "led.h"
int main()
{
	led_init();
	led(0x0f,1);
	
	//配置k2 GPX1_1 为input模式
	GPX1.CON &= ~(0xf << 4); 

	
	while(1)
	{
		if(GPX1.DAT & (1<<1) )
		{
			//按键弹起
			led(0x0f,1);
		}
		else 
		{
			led(0x07,0);
		}
		
	}



    return 0;
}




