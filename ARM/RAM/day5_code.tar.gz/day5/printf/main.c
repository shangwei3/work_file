
#include"exynos_4412.h"
#include"uart.h"


int main()
{
    int a = 100;
    uart_init();
    printf("hello!a=%d\r\n",a);
    while(1);
    return 0;
}

