#include "uart.h"
#include "exynos_4412.h"

int main()
{
	char a;
	uart_init();	
	
	puts("hello word!\n\r");


	while(1)
	{
		if( UART2.UTRSTAT2 & 1)
		{
			//收到数据,发送接收到的数据
			//等待上一次发生完成
			while( !(UART2.UTRSTAT2 & 2));
			a = UART2.URXH2;
			UART2.UTXH2	= a;
			
		}
	}


    return 0;
}
