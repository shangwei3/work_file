#ifndef __KEY_H
#define __KEY_H 

#define  K2 57
#define  K3 58
#define  K4 64

typedef  void (*irq_tp)(int irq_num);

void key_init(irq_tp irq_f);




#endif
