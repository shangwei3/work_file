#include "exynos_4412.h"


int main()
{
	//GPX2_7  
	GPX2.CON = (GPX2.CON & ~(0xf << 28)) | (1 << 28);
	GPX2.DAT |= 1<< 7;
	GPX2.PUD &= ~(3<<14); 
	while(1);	
    return 0;
}

