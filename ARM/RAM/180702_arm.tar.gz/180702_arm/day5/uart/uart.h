#ifndef __UART_H
#define __UART_H 

void uart_init(void);
void putc(char c);
void puts(char *s);



#endif 

