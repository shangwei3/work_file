#include "uart.h"
#include "exynos_4412.h"
#include "led.h"

int main()
{
	char a,b;
	char con;
	uart_init();	
	led_init();

	printf("hello word!\n\r");


	while(1)
	{
		if( UART2.UTRSTAT2 & 1)
		{
			//收到数据,发送接收到的数据
			//等待上一次发生完成
			while( !(UART2.UTRSTAT2 & 2));
			a = UART2.URXH2;
			UART2.UTXH2	= a;
			if(a== '1')
			{
				b = get_led_flag();
				con =  ( (~b) & 1);
				led(con,con);
				printf("b=%d,%d\n\r",b,con);
			}
		}
	}


    return 0;
}
