
#include"exynos_4412.h"
#include"uart.h"
#include"wdt.h"


int main()
{
	int i,j;
	wdt_init();
    uart_init();
    printf("hello!sdt start!\r\n");
    while(1)
	{
		//定期喂狗
		for(i=0;i<100;i++)
			for(j=0;j<1000;j++);
//		WDT.WTCNT = 6250;
	}
    return 0;
}

