#ifndef __WDT_H
#define __WDT_H

void wdt_init(void);


#endif 
