#include "exynos_4412.h"

void pwm_init(unsigned int p,unsigned int b)
{
	//GPIO
	GPD0.CON = (GPD0.CON & ~(0xf) )| 0x2;
	//PWM 
	//预分频1
	PWM.TCFG0 &= ~0xff ;
	//设置固定分频 1/1
	PWM.TCFG1 = (PWM.TCFG1 & ~0xf);
	//重载 1M
	PWM.TCNTB0 = p;
	//比较值
	PWM.TCMPB0 = b;
	//使能更新
	PWM.TCON  |= 1<<1;
	//关闭使能更新
	PWM.TCON  &= ~(1<<1);
	//使能自动重载和使能输出
	PWM.TCON  |= 3<<2;
}

void pwm_start(void)
{
	PWM.TCON |= 1;
}

void pwm_stop(void)
{
	PWM.TCON &= ~1;
}


