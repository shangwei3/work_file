
#include"exynos_4412.h"
#include"uart.h"
#include"pwm.h"

int main()
{
    uart_init();
	pwm_init(1000000,500000);
	pwm_start();
    while(1);
    return 0;
}

