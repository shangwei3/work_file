#ifndef __ADC_H
#define __ADC_H 

void adc_init(void);
unsigned short get_adc_data(void);

#endif 
