
#include"exynos_4412.h"
#include"uart.h"
#include"pwm.h"
#include"adc.h"


int main()
{
	unsigned int data;
    uart_init();
//	pwm_init(1000000,500000);
//	pwm_start();
	delay_init();	
	adc_init();
    while(1)
	{
		data = get_adc_data();
		printf("adc=%d\n\r",data);
		delayms(250);
	}
    return 0;
}

