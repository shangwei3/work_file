#ifndef __KEY_H
#define __KEY_H 


void key_init(void);




#endif
