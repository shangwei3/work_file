#include "exynos_4412.h"


void key_init(void)
{
	//配置GPIO
	GPX1.CON |= 0xf << 4;
	EXT_INT41_CON = (EXT_INT41_CON & ~ (0x7 << 4)) | (0x3 << 4);
	
	EXT_INT41_MASK &= ~(1<<1); 

	//配置GIC
	ICDDCR |= 1;//4、总中断使能
	//5、使能端口中断
	ICDISER.ICDISER1 |= 1<<25;
	//6、端口优先级配置
	ICDIPR.ICDIPR14  &= ~(0xff<<8);
	//7、配置中断源可以被哪个或哪些CPU相应
	ICDIPTR.ICDIPTR14 =( ICDIPTR.ICDIPTR14 & ~(0xff<<8)) | (0x1 <<8);
	//8、CPU 中断使能寄存器
	CPU0.ICCICR  |= 1;
	//9、CPU 优先级过滤寄存器
	CPU0.ICCPMR |= 0xff;

}

