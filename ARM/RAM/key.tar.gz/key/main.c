
#include"exynos_4412.h"
#include"uart.h"


int main()
{
    int a = 100;
    uart_init();
    printf("hello!a=%d\r\n",a);

	key_init();

    while(1);
    return 0;
}

void do_irq(void )
{
	int irq_id ;
	//1、获取中断ID
	irq_id = CPU0.ICCIAR;
	//2、判断中断ID,对不同中断做相应的处理
	switch (irq_id)
	{
		case 57:
			printf("key down!irq_id=%d\r\n",irq_id);
			//清除GPIO中断挂起
			EXT_INT41_PEND |= 1<<1;
			//清除GIC中断挂起
			ICDICPR.ICDICPR1 |= 1<<25;
	}
	//结束中断
	CPU0.ICCEOIR = irq_id;
}


