#include "exynos_4412.h"


void wdt_init(void)
{
	//配置预分频
	WDT.WTCON = (WDT.WTCNT & ~(0xff << 8)) | (124 << 8);
	//固定分频128
	WDT.WTCON |= 0x3 << 3;
	//设置初始计数值
	WDT.WTCNT  = 6250;
	
	//是能看门狗
	WDT.WTCON |= 1<<5;
	//复位信号使能
	WDT.WTCON |= 1;
	
}



